package CustomeTable;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class VIncomeManagement_Table_ActionButton  extends JButton
{
    public VIncomeManagement_Table_ActionButton()
    {
        setContentAreaFilled(false);
        setBorder(new EmptyBorder(3,3,3,3));
    }
}
