
package budget.expense.management.system.v0.pkg1;
import view.*;

public class BudgetExpenseManagementSystemV01 
{

    public static void main(String[] args)
    {
        VSignIn vsi = new VSignIn();
        vsi.setVisible(true);
    }
    
}
